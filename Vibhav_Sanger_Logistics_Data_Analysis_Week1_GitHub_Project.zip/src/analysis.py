import pandas as pd

def load_data(path: str) -> pd.DataFrame:
    return pd.read_csv(path)

def prepare_dates(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in ["Order_Date", "Dispatch_Date", "Delivery_Date", "Promised_Date"]:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")
    return df

def calculate_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if {"Delivery_Date", "Dispatch_Date"}.issubset(df.columns):
        df["Delivery_Time_Hours"] = (
            df["Delivery_Date"] - df["Dispatch_Date"]
        ).dt.total_seconds() / 3600
    if {"Delivery_Date", "Promised_Date"}.issubset(df.columns):
        df["Late_Flag"] = (df["Delivery_Date"] > df["Promised_Date"]).astype(int)
    return df

def calculate_kpis(df: pd.DataFrame) -> dict:
    result = {}
    if "Late_Flag" in df.columns:
        result["on_time_delivery_rate_pct"] = (1 - df["Late_Flag"].mean()) * 100
        result["delay_rate_pct"] = df["Late_Flag"].mean() * 100
    if "Delivery_Time_Hours" in df.columns:
        result["average_delivery_time_hours"] = df["Delivery_Time_Hours"].mean()
    if "Shipping_Cost" in df.columns:
        result["average_cost_per_delivery"] = df["Shipping_Cost"].mean()
    return result
