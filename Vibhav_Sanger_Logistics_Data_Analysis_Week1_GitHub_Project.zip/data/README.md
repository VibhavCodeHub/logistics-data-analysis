# Data

This folder contains datasets used for the project.

For Week 1, the repository includes synthetic/sample data only.

**Before uploading any YuvaIntern dataset to GitHub, confirm that publication is permitted. Do not upload confidential company or personal data.**
